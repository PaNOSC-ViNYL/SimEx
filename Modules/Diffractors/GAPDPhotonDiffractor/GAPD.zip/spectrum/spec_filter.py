# spec_filter.py

import sys as sys
import time
import numpy as np
from scipy.interpolate import interp1d


## IO ##
if (len(sys.argv) < 6):
    print "Usage: python",sys.argv[0],"start end step input_file output_file"
else:
    start = float(sys.argv[1])
    end = float(sys.argv[2])
    step = float(sys.argv[3])
    filename = str(sys.argv[4])
    savename = str(sys.argv[5])
    print 'start = '+str(start)
    print 'end = '+str(end)
    print 'step = '+str(step)
    with open(filename) as f:
        with open(savename,"w") as of:
            print time.strftime('%H:%M:%S',time.localtime(time.time()))
            data = np.genfromtxt(filename, skip_header=1)
            f = interp1d(data[:,0], data[:,1])
            # n_points = int(data.shape[0]*percent)
            # print 'n_points = '+str(n_points)
            # x = np.linspace(start, end, num=n_points, endpoint=True)
            x = np.arange(start, end+step,step)
            y = f(x)
            c = np.vstack((x,y))
            np.savetxt(savename, c.T)


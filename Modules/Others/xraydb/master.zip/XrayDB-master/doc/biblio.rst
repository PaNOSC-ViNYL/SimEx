
References
==================================

.. bibliography:: xraydb.bib
    :cited:
    :list: citation_key
